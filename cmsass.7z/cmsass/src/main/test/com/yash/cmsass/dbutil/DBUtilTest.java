package com.yash.cmsass.dbutil;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

/**
 * This DBUtil test class will test for the connection object and driver class creation  
 * @author nitesh.yadav
 *
 */
public class DBUtilTest {
/**
 * Test case for the driver
 */
	@Rule
    public ExpectedException thrown = ExpectedException.none();
	@Test(expected = ClassNotFoundException.class)
	public void test_on_driver() throws ClassNotFoundException {
		DBUtil db=new DBUtil("com.mysql.jdbc.Driver");
		
	
	}
/**
 * Test case for the getting connection and checking the database name got in the connectin object. By using the getcatalog method
 * the connection object
 */
	@Test
	public void test_for_connection() {
	String url="jdbc:mysql://localhost/cmsass";
	String user="root";
	String pass="root";
	DBUtil db=new DBUtil();
	Connection con=db.getConnection(url,user,pass);
	try {
		
		String database=con.getCatalog();
	assertEquals("cmsass",database);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
}
