package com.yash.cmsass.main;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.yash.cmsass.dao.CourseDao;
import com.yash.cmsass.daoimpl.CourseDaoImpl;
import com.yash.cmsass.service.CourseService;
import com.yash.cmsass.serviceimpl.CourseServiceImpl;

public class Startup {
public static void main(String[] args) {
	CourseService courseService =new CourseServiceImpl();
	Map<String, ArrayList<String>> courseandtitle=courseService.getAllCourseDetails();
	for (Map.Entry<String , ArrayList<String>> entry : courseandtitle.entrySet()) {
	    System.out.println(entry.getKey()+" : "+entry.getValue());
	}
}
}
