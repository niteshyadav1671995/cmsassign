package com.yash.cmsass.dao;

import java.util.List;

public interface CourseDao {
public List<String> getCourse();
public List<String> getMainTitle(String courseName);

}
