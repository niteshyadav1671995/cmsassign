package com.yash.cmsass.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 * This is the class used for providing the database connection and loading the driver for database mysql
 * @author nitesh.yadav
 *
 */
public class DBUtil {
/**
 * Constructor of the DBUtil class 
 */
	public DBUtil() {
		// TODO Auto-generated constructor stub
	}
/**
 * Constructor for DBUtil which will create the driver of the mysql 
 * @param driver
 * @throws ClassNotFoundException 
 */
	public DBUtil(String driver) throws ClassNotFoundException{
			Class c = null;
			c = Class.forName(driver);
			System.out.println(c);
	}
	
	/**
	 * Get Connection will return the connection object of the mysql's database
	 * @param url url of the database
	 * @param user user of the database
	 * @param pass pass of the database
	 * @return
	 */

	public Connection getConnection(String url, String user, String pass) {
		/**
		 * Connection object is created with null parameter
		 */
		Connection con = null;

		try {
			/**
			 * Here con will get the connection for given url,user and pass
			 */
			con = DriverManager.getConnection(url, user, pass);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return con;
	}
	

}
