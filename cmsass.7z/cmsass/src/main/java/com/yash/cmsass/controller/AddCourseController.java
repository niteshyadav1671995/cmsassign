package com.yash.cmsass.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.cmsass.service.CourseService;
import com.yash.cmsass.serviceimpl.CourseServiceImpl;


public class AddCourseController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CourseService courseService;
	public void init() throws ServletException {
		courseService =new CourseServiceImpl();
		super.init();
    }
@Override
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	Map<String, ArrayList<String>> courseandtitle=courseService.getAllCourseDetails();
	for (Map.Entry<String , ArrayList<String>> entry : courseandtitle.entrySet()) {
	System.out.println(entry.getKey()+" : "+entry.getValue());}
	PrintWriter out=response.getWriter();
	out.println("<html>");
    out.println("<head>");
    out.println("<title>Subtitle Upload</title>");
    out.println("</head>");
    out.println("<body>");
    out.println("<center>");
    out.println("<fieldset style='width: 300px'>");
    out.println("<legend>Add Sub Title</legend>");
    out.println("<form action='AddCourseController' method='post'>");
    out.println("<table>");
    out.println("<tr>");
    out.println("<td>Course :");
    out.println("<select name='course' onchange='this.form.submit()'>");
    out.println("<option disabled selected>--select an option--</option>");
    for (Map.Entry<String , ArrayList<String>> entry : courseandtitle.entrySet()) {
   out.println("<option value='"+entry.getKey()+"'>"+(entry.getKey())+"</option>");
   }
    out.println("</select>");
    out.println("</td>");
    out.println("<td>");
    out.println("Subtitle<input type='text'>");
    out.println("</td>");
    out.println("</tr>");
    out.println("<tr>");
    out.println("<td>Main Title:");
    out.println("<select name='mainTitle'>");
    out.println("<<option disabled selected>--select an option--</option>");
    out.println("<option value='java'>JAVA</option>");
    out.println("</select>");
    out.println("</td>");
    out.println("<td>");
    out.printf("Upload File <input type='file'>");
    out.println("</td>");
    out.println("</tr>");
    out.println("<tr>");
    out.println("<td>Description</td>");
    out.println("</tr>");
    out.println("<tr>");
    out.println("<td colspan='2'><textarea rows='5' cols='40'></textarea></td>");
    out.println("</tr>");
    out.println("<tr>");
    out.println("<td colspan='2'>Publish<input name='publish' type='checkbox' checked /></td>");
    out.println("</tr>");
    out.println("<tr>");
    out.println("<td colspan='2' style='text-align: right;'><input type='submit' value='Submit'/></td>");
    out.println("</tr>");
    out.println("</table>");
    out.println("</form>");
    out.println("</fieldset>");
    out.println("</center>");
    out.println("</body>");
    out.println("</html>");
//	doPost(request, response);
}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Map<String, ArrayList<String>> courseandtitle=courseService.getAllCourseDetails();
		String course=request.getParameter("course");
		ArrayList<String> maintitle=new ArrayList<String>();
		for (Map.Entry<String , ArrayList<String>> entry : courseandtitle.entrySet()) {
			if(entry.getKey().equalsIgnoreCase(course))
			for(int i=0;i<entry.getValue().size();i++){
			maintitle.add(entry.getValue().get(i));
			}
		}
		courseandtitle.remove(course);
		
		PrintWriter out=response.getWriter();
		out.println("<html>");
	    out.println("<head>");
	    out.println("<title>Subtitle Upload</title>");
	    out.println("</head>");
	    out.println("<body>");
	    out.println("<center>");
	    out.println("<fieldset style='width: 300px'>");
	    out.println("<legend>Add Sub Title</legend>");
	    out.println("<form action='AddCourseController' method='post'>");
	    out.println("<table>");
	    out.println("<tr>");
	    out.println("<td>Course :");
	    out.println("<select name='course' onchange='this.form.submit()'>");
	    out.println("<option value="+course+">"+course+"</option>");
	    for (Map.Entry<String , ArrayList<String>> entry : courseandtitle.entrySet()) {
	    	   out.println("<option value='"+entry.getKey()+"'>"+(entry.getKey())+"</option>");
	    	   }
	    out.println("</select>");
	    out.println("</td>");
	    out.println("<td>");
	    out.println("Subtitle<input type='text'>");
	    out.println("</td>");
	    out.println("</tr>");
	    out.println("<tr>");
	    out.println("<td>Main Title:");
	    out.println("<select name='mainTitle'>");
	    out.println("<<option disabled selected>--select an option--</option>");
	  for (String maintitletemp : maintitle) {
		   out.println("<option value='"+maintitletemp+"'>"+maintitletemp+"</option>");
	  }
	 
	    out.println("</select>");
	    out.println("</td>");
	    out.println("<td>");
	    out.printf("Upload File <input type='file'>");
	    out.println("</td>");
	    out.println("</tr>");
	    out.println("<tr>");
	    out.println("<td>Description</td>");
	    out.println("</tr>");
	    out.println("<tr>");
	    out.println("<td colspan='2'><textarea rows='5' cols='40'></textarea></td>");
	    out.println("</tr>");
	    out.println("<tr>");
	    out.println("<td colspan='2'>Publish<input name='publish' type='checkbox' checked /></td>");
	    out.println("</tr>");
	    out.println("<tr>");
	    out.println("</form>");
	    out.println("<form action='SaveDataController'>");
	    out.println("<td colspan='2' style='text-align: right;'><input type='submit' value='Submit'/></td>");
	    out.println("</tr>");
	    out.println("</table>");
	    out.println("</form>");
	    out.println("</fieldset>");
	    out.println("</center>");
	    out.println("</body>");
	    out.println("</html>");

			}
}
