package com.yash.cmsass.service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface CourseService {
public List<String> getCourseService();
public List<String> getMainTitleService(String courseName);
public LinkedHashMap<String, ArrayList<String>> getAllCourseDetails();
public void showInterface(String course, HttpServletResponse response, HttpServletRequest request);
}
