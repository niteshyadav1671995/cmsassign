package com.yash.cmsass.serviceimpl;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.jasper.tagplugins.jstl.core.ForEach;

import com.yash.cmsass.dao.CourseDao;
import com.yash.cmsass.daoimpl.CourseDaoImpl;
import com.yash.cmsass.service.CourseService;

public class CourseServiceImpl implements CourseService {
	CourseDao coursedao;
	public CourseServiceImpl() {
		coursedao=new CourseDaoImpl();
		}
	public List<String> getCourseService() {
		List<String> courses=coursedao.getCourse();
		return courses;
	}

	public List<String> getMainTitleService(String courseName) {
		List<String> maintitle=coursedao.getMainTitle(courseName); 
		return maintitle;
	}

	public LinkedHashMap<String, ArrayList<String>> getAllCourseDetails() {
		LinkedHashMap<String,ArrayList<String>> courseAndTitle=new LinkedHashMap<String, ArrayList<String>>();
		ArrayList<String> courses=(ArrayList<String>) getCourseService();
		for (String course : courses) {
			courseAndTitle.put(course,(ArrayList<String>)getMainTitleService(course));
		}
		return courseAndTitle;
	}
	
	public void showInterface(String course, HttpServletResponse response, HttpServletRequest request){
		Map<String, ArrayList<String>> courseandtitle=getAllCourseDetails();
		PrintWriter out;
		try {
			out = response.getWriter();
			out.println("<html>");
		    out.println("<head>");
		    out.println("<title>Subtitle Upload</title>");
		    out.println("</head>");
		    out.println("<body>");
		    out.println("<center>");
		    out.println("<fieldset style='width: 300px'>");
		    out.println("<legend>Add Sub Title</legend>");
		    out.println("<form action='CourseUploadController' method='post'>");
		    out.println("<table>");
		    out.println("<tr>");
		    out.println("<td>Course :");
		    out.println("<select name='course' onchange='this.form.submit()'>");
		    out.println("<option disabled selected>--select an option--</option>");
		    for (Map.Entry<String , ArrayList<String>> entry : courseandtitle.entrySet()) {
		    if(course.equals(""+entry.getKey()+"")){
		    out.println("<option value='"+entry.getKey()+"' "+course+">"+(entry.getKey())+"</option>");
		    }
		    else{out.println("<option value='"+entry.getKey()+"'>"+(entry.getKey())+"</option>");}
		    }
		    out.println("</select>");
		    out.println("</td>");
		    out.println("<td>");
		    out.println("Subtitle<input type='text'>");
		    out.println("</td>");
		    out.println("</tr>");
		    out.println("<tr>");
		    out.println("<td>Main Title:");
		    out.println("<select name='mainTitle'>");
		    out.println("<<option disabled selected>--select an option--</option>");
		    out.println("<option value='java'>JAVA</option>");
		    out.println("</select>");
		    out.println("</td>");
		    out.println("<td>");
		    out.printf("Upload File <input type='file'>");
		    out.println("</td>");
		    out.println("</tr>");
		    out.println("<tr>");
		    out.println("<td>Description</td>");
		    out.println("</tr>");
		    out.println("<tr>");
		    out.println("<td colspan='2'><textarea rows='5' cols='40'></textarea></td>");
		    out.println("</tr>");
		    out.println("<tr>");
		    out.println("<td colspan='2'>Publish<input name='publish' type='checkbox' checked /></td>");
		    out.println("</tr>");
		    out.println("<tr>");
		    out.println("<td colspan='2' style='text-align: right;'><input type='submit' value='Submit'/></td>");
		    out.println("</tr>");
		    out.println("</table>");
		    out.println("</form>");
		    out.println("</fieldset>");
		    out.println("</center>");
		    out.println("</body>");
		    out.println("</html>");
		} catch (IOException e) {
		
			e.printStackTrace();
		}
	}


}
