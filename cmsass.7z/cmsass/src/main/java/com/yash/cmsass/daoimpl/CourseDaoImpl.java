package com.yash.cmsass.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.yash.cmsass.dao.CourseDao;
import com.yash.cmsass.dbutil.DBUtil;

public class CourseDaoImpl implements CourseDao{
	Connection con=null;
	public CourseDaoImpl() {
		try {
			String url="jdbc:mysql://localhost/cmsass";
			String user="root";
			String pass="root";
			DBUtil dbutil=new DBUtil("com.mysql.jdbc.Driver");
			con=dbutil.getConnection(url, user, pass);
		} catch (ClassNotFoundException e) {
		}
	}
	public List<String> getCourse() {
		String sql="select course from course group by course";
		List<String> courses=new ArrayList<String>();
		try {
			PreparedStatement pstmt=con.prepareStatement(sql);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				courses.add(rs.getString(1));
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return courses;
	}

	public List<String> getMainTitle(String courseName) {
		String sql="select maintitle from course where course= ? group by maintitle";
		List<String> maintitle=new ArrayList<String>();
		try {
			PreparedStatement pstmt=con.prepareStatement(sql);
			pstmt.setString(1, courseName);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				maintitle.add(rs.getString(1));
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return maintitle;
	}

	public String[] getSubTitle(String courseName, String mainTitle) {
		// TODO Auto-generated method stub
		return null;
	}

}
